'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'

interface Profile {
  id: string
  username: string
  full_name: string | null
  bio: string | null
  avatar_url: string | null
  button_text: string | null
  button_url: string | null
}

export default function ProfileSection() {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const supabase = createClient()
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .limit(1)
          .single()

        if (error && error.code !== 'PGRST116') {
          console.error('Error fetching profile:', error)
        } else if (data) {
          setProfile(data)
        }
      } catch (error) {
        console.error('Error:', error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchProfile()
  }, [])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <div className="animate-pulse text-foreground/50">Loading profile...</div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="flex flex-col items-center justify-center w-full h-full p-8 text-center">
        <p className="text-foreground/50">No profile found</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col justify-center w-full h-full p-6 md:p-8">
      {/* Profile Content */}
      <div className="flex flex-col justify-center">
        {profile.avatar_url && (
          <img
            src={profile.avatar_url}
            alt="Profile avatar"
            className="w-20 h-20 md:w-24 md:h-24 rounded-lg object-cover mb-4 border border-border"
          />
        )}
        
        {profile.bio && (
          <p className="text-sm text-foreground/60 leading-relaxed max-w-sm mb-6">
            {profile.bio}
          </p>
        )}

        {/* CTA Button */}
        {profile.button_text && profile.button_url && (
          <a href={profile.button_url} target="_blank" rel="noopener noreferrer" className="block">
            <Button className="w-full text-sm">{profile.button_text}</Button>
          </a>
        )}
      </div>
    </div>
  )
}
