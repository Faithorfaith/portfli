'use client'

import { useState } from 'react'
import Image from 'next/image'

interface WorkCardProps {
  work: {
    id: string
    title: string
    description: string | null
    media_url: string
    media_type: 'image' | 'video'
    thumbnail_url: string | null
  }
}

export default function WorkCard({ work }: WorkCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const mediaUrl = work.thumbnail_url || work.media_url

  return (
    <div
      className="group relative aspect-square bg-muted rounded-lg overflow-hidden cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Media */}
      {work.media_type === 'image' ? (
        <img
          src={mediaUrl}
          alt={work.title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          onLoad={() => setIsLoading(false)}
        />
      ) : (
        <video
          src={work.media_url}
          poster={work.thumbnail_url}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          onLoadedMetadata={() => setIsLoading(false)}
        >
          Your browser does not support the video tag.
        </video>
      )}

      {/* Loading skeleton */}
      {isLoading && (
        <div className="absolute inset-0 bg-muted animate-pulse" />
      )}

      {/* Overlay */}
      <div
        className={`absolute inset-0 bg-black/0 transition-all duration-300 ${
          isHovered ? 'bg-black/40' : ''
        }`}
      />

      {/* Info on hover */}
      {isHovered && (
        <div className="absolute inset-0 flex flex-col justify-end p-4 text-white bg-gradient-to-t from-black/80 via-transparent">
          <h3 className="font-semibold text-base mb-1 line-clamp-2">
            {work.title}
          </h3>
          {work.description && (
            <p className="text-sm text-white/70 line-clamp-2">
              {work.description}
            </p>
          )}
        </div>
      )}

      {/* Play button for videos */}
      {work.media_type === 'video' && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/30 transition-colors">
            <svg
              className="w-6 h-6 text-white fill-current"
              viewBox="0 0 24 24"
            >
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
      )}
    </div>
  )
}
