'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { createClient } from '@/lib/supabase/client'
import WorkCard from './work-card'

interface Work {
  id: string
  title: string
  description: string | null
  media_url: string
  media_type: 'image' | 'video'
  thumbnail_url: string | null
  order_index: number
  created_at: string
}

const ITEMS_PER_PAGE = 12

export default function WorksGallery() {
  const [works, setWorks] = useState<Work[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [page, setPage] = useState(0)
  const observerTarget = useRef<HTMLDivElement>(null)

  const fetchWorks = useCallback(
    async (pageNum: number) => {
      if (isLoading || !hasMore) return

      setIsLoading(true)
      try {
        const supabase = createClient()
        const { data, error, count } = await supabase
          .from('portfolio_works')
          .select('*', { count: 'exact' })
          .order('order_index', { ascending: true })
          .order('created_at', { ascending: false })
          .range(pageNum * ITEMS_PER_PAGE, (pageNum + 1) * ITEMS_PER_PAGE - 1)

        if (error) {
          console.error('Error fetching works:', error)
        } else if (data) {
          setWorks((prev) => [...prev, ...data])
          const totalFetched = (pageNum + 1) * ITEMS_PER_PAGE
          if (count !== null && totalFetched >= count) {
            setHasMore(false)
          }
        }
      } catch (error) {
        console.error('Error:', error)
      } finally {
        setIsLoading(false)
      }
    },
    [isLoading, hasMore]
  )

  // Initial load
  useEffect(() => {
    fetchWorks(0)
    setPage(1)
  }, [])

  // Infinite scroll observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !isLoading) {
          fetchWorks(page)
          setPage((prev) => prev + 1)
        }
      },
      { threshold: 0.1 }
    )

    if (observerTarget.current) {
      observer.observe(observerTarget.current)
    }

    return () => {
      if (observerTarget.current) {
        observer.unobserve(observerTarget.current)
      }
    }
  }, [page, hasMore, isLoading, fetchWorks])

  return (
    <div className="w-full bg-background">
      <div id="works" className="p-6 md:p-8">
        {works.length === 0 && !isLoading ? (
          <div className="flex items-center justify-center py-16">
            <p className="text-foreground/50">No works yet</p>
          </div>
        ) : (
          <>
            {/* Gallery Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
              {works.map((work) => (
                <WorkCard key={work.id} work={work} />
              ))}
            </div>

            {/* Infinite scroll trigger */}
            {hasMore && (
              <div ref={observerTarget} className="py-8 text-center">
                {isLoading && (
                  <div className="animate-pulse text-foreground/50">
                    Loading more works...
                  </div>
                )}
              </div>
            )}

            {!hasMore && works.length > 0 && (
              <div className="py-8 text-center text-foreground/50 text-sm">
                No more works to load
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
