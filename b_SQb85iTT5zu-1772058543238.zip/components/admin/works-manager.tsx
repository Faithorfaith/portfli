'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import FileUpload from './file-upload'

interface Work {
  id: string
  media_url: string
  media_type: 'image' | 'video'
  created_at: string
}

interface WorksManagerProps {
  userId: string
}

export default function WorksManager({ userId }: WorksManagerProps) {
  const [works, setWorks] = useState<Work[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [isAdding, setIsAdding] = useState(false)
  const [formData, setFormData] = useState({
    media_url: '',
    media_type: 'image' as 'image' | 'video',
  })

  // Fetch works
  useEffect(() => {
    const fetchWorks = async () => {
      try {
        const supabase = createClient()
        const { data, error: fetchError } = await supabase
          .from('portfolio_works')
          .select('id, media_url, media_type, created_at')
          .eq('user_id', userId)
          .order('created_at', { ascending: false })

        if (fetchError) throw fetchError
        setWorks(data || [])
      } catch (err) {
        console.error('Error fetching works:', err)
        setError('Failed to load works')
      } finally {
        setIsLoading(false)
      }
    }

    if (userId) fetchWorks()
  }, [userId])

  const handleMediaUpload = (url: string) => {
    setFormData((prev) => ({ ...prev, media_url: url }))
  }

  const handleMediaTypeChange = (type: 'image' | 'video') => {
    setFormData({ media_url: '', media_type: type })
  }

  const handleSave = async () => {
    if (!formData.media_url.trim()) {
      setError('Please upload media first')
      return
    }

    setError(null)
    setSuccess(false)

    try {
      const supabase = createClient()
      const { error: insertError } = await supabase
        .from('portfolio_works')
        .insert([{
          user_id: userId,
          media_url: formData.media_url,
          media_type: formData.media_type,
          title: '',
          description: null,
        }])

      if (insertError) throw insertError

      // Refresh works list
      const { data, error: fetchError } = await supabase
        .from('portfolio_works')
        .select('id, media_url, media_type, created_at')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })

      if (fetchError) throw fetchError
      setWorks(data || [])

      setSuccess(true)
      resetForm()
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      console.error('Error saving work:', err)
      setError('Failed to save work')
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this work?')) return

    try {
      const supabase = createClient()
      const { error: deleteError } = await supabase
        .from('portfolio_works')
        .delete()
        .eq('id', id)

      if (deleteError) throw deleteError
      setWorks((prev) => prev.filter((work) => work.id !== id))
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      console.error('Error deleting work:', err)
      setError('Failed to delete work')
    }
  }

  const resetForm = () => {
    setFormData({ media_url: '', media_type: 'image' })
    setIsAdding(false)
  }

  if (isLoading) {
    return <div className="animate-pulse text-foreground/50">Loading...</div>
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-foreground">Portfolio Works</h2>
        {!isAdding && (
          <Button onClick={() => setIsAdding(true)}>Add Work</Button>
        )}
      </div>

      {error && (
        <div className="p-3 bg-red-500/10 border border-red-500/20 rounded text-red-600 text-sm">
          {error}
        </div>
      )}

      {success && (
        <div className="p-3 bg-green-500/10 border border-green-500/20 rounded text-green-600 text-sm">
          Work saved successfully!
        </div>
      )}

      {/* Add Form */}
      {isAdding && (
        <div className="max-w-2xl border border-border rounded-lg p-6 bg-background/50">
          <h3 className="text-lg font-semibold text-foreground mb-4">Add Portfolio Work</h3>

          <div className="space-y-4">
            {/* Media Type */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Media Type
              </label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={formData.media_type === 'image' ? 'default' : 'outline'}
                  onClick={() => handleMediaTypeChange('image')}
                >
                  Image
                </Button>
                <Button
                  type="button"
                  variant={formData.media_type === 'video' ? 'default' : 'outline'}
                  onClick={() => handleMediaTypeChange('video')}
                >
                  Video
                </Button>
              </div>
            </div>

            {/* Media Upload */}
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                {formData.media_type === 'image' ? 'Upload Image' : 'Upload Video'} *
              </label>
              {formData.media_url && (
                <p className="text-sm text-foreground/60 mb-2">
                  File: {formData.media_url.split('/').pop()}
                </p>
              )}
              <FileUpload
                userId={userId}
                folder={formData.media_type === 'image' ? 'portfolio-images' : 'portfolio-videos'}
                onUpload={handleMediaUpload}
                accept={formData.media_type === 'image' ? 'image/*' : 'video/*'}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button onClick={handleSave} className="flex-1">
                Upload Work
              </Button>
              <Button onClick={resetForm} variant="outline" className="flex-1">
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Works List */}
      <div className="space-y-3">
        {works.length === 0 ? (
          <p className="text-foreground/50 text-center py-8">No works yet</p>
        ) : (
          works.map((work) => (
            <div
              key={work.id}
              className="flex items-center gap-4 p-4 border border-border rounded-lg hover:bg-background/50 transition-colors"
            >
              {/* Media Preview */}
              {work.media_type === 'image' && work.media_url && (
                <img
                  src={work.media_url}
                  alt="Portfolio work"
                  className="w-16 h-16 rounded object-cover flex-shrink-0"
                />
              )}
              {work.media_type === 'video' && (
                <div className="w-16 h-16 rounded bg-muted flex items-center justify-center flex-shrink-0">
                  <svg
                    className="w-6 h-6 text-foreground/50"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              )}

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground/60">
                  {new Date(work.created_at).toLocaleDateString()}
                </p>
              </div>

              {/* Delete Button */}
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleDelete(work.id)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/20"
              >
                Delete
              </Button>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
