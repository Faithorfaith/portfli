'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import FileUpload from './file-upload'

interface Profile {
  id: string
  username: string
  full_name: string | null
  bio: string | null
  avatar_url: string | null
  button_text: string | null
  button_url: string | null
}

interface ProfileManagerProps {
  userId: string
}

export default function ProfileManager({ userId }: ProfileManagerProps) {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [formData, setFormData] = useState({
    username: '',
    full_name: '',
    bio: '',
    avatar_url: '',
    button_text: '',
    button_url: '',
  })
  const supabase = createClient()

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const { data, error: fetchError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single()

        if (fetchError && fetchError.code !== 'PGRST116') {
          throw fetchError
        }

        if (data) {
          setProfile(data)
          setFormData({
            username: data.username || '',
            full_name: data.full_name || '',
            bio: data.bio || '',
            avatar_url: data.avatar_url || '',
            button_text: data.button_text || '',
            button_url: data.button_url || '',
          })
        } else {
          // Create new profile if doesn't exist
          const { data: newProfile, error: createError } = await supabase
            .from('profiles')
            .insert([{ id: userId, username: '' }])
            .select()
            .single()

          if (createError) throw createError
          if (newProfile) {
            setProfile(newProfile)
          }
        }
      } catch (err) {
        console.error('Error fetching profile:', err)
        setError('Failed to load profile')
      } finally {
        setIsLoading(false)
      }
    }

    if (userId) fetchProfile()
  }, [userId, supabase])

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleAvatarUpload = (url: string) => {
    setFormData((prev) => ({ ...prev, avatar_url: url }))
  }

  const handleSave = async () => {
    if (!formData.username.trim()) {
      setError('Username is required')
      return
    }

    setIsSaving(true)
    setError(null)
    setSuccess(false)

    try {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          username: formData.username,
          full_name: formData.full_name || null,
          bio: formData.bio || null,
          avatar_url: formData.avatar_url || null,
          button_text: formData.button_text || null,
          button_url: formData.button_url || null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId)

      if (updateError) throw updateError

      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      console.error('Error saving profile:', err)
      setError('Failed to save profile')
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return <div className="animate-pulse text-foreground/50">Loading...</div>
  }

  return (
    <div className="max-w-2xl">
      <h2 className="text-xl font-bold text-foreground mb-6">Edit Profile</h2>

      {error && (
        <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded text-red-600 text-sm">
          {error}
        </div>
      )}

      {success && (
        <div className="mb-4 p-3 bg-green-500/10 border border-green-500/20 rounded text-green-600 text-sm">
          Profile updated successfully!
        </div>
      )}

      <div className="space-y-6">
        {/* Avatar Upload */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Avatar
          </label>
          {formData.avatar_url && (
            <img
              src={formData.avatar_url}
              alt="Avatar preview"
              className="w-32 h-32 rounded-lg object-cover mb-4 border border-border"
            />
          )}
          <FileUpload
            userId={userId}
            folder="avatars"
            onUpload={handleAvatarUpload}
            accept="image/*"
          />
        </div>

        {/* Username */}
        <div>
          <label htmlFor="username" className="block text-sm font-medium text-foreground mb-2">
            Username *
          </label>
          <Input
            id="username"
            name="username"
            value={formData.username}
            onChange={handleInputChange}
            placeholder="your_username"
            className="bg-background border-border"
          />
        </div>

        {/* Full Name */}
        <div>
          <label htmlFor="full_name" className="block text-sm font-medium text-foreground mb-2">
            Full Name
          </label>
          <Input
            id="full_name"
            name="full_name"
            value={formData.full_name}
            onChange={handleInputChange}
            placeholder="John Doe"
            className="bg-background border-border"
          />
        </div>

        {/* Bio */}
        <div>
          <label htmlFor="bio" className="block text-sm font-medium text-foreground mb-2">
            Bio
          </label>
          <Textarea
            id="bio"
            name="bio"
            value={formData.bio}
            onChange={handleInputChange}
            placeholder="Tell us about yourself..."
            rows={4}
            className="bg-background border-border resize-none"
          />
        </div>

        {/* CTA Button Text */}
        <div>
          <label htmlFor="button_text" className="block text-sm font-medium text-foreground mb-2">
            Button Text (CTA)
          </label>
          <Input
            id="button_text"
            name="button_text"
            value={formData.button_text}
            onChange={handleInputChange}
            placeholder="e.g., Contact Me, View My Work"
            className="bg-background border-border"
          />
        </div>

        {/* CTA Button URL */}
        <div>
          <label htmlFor="button_url" className="block text-sm font-medium text-foreground mb-2">
            Button URL
          </label>
          <Input
            id="button_url"
            name="button_url"
            value={formData.button_url}
            onChange={handleInputChange}
            placeholder="https://example.com"
            className="bg-background border-border"
          />
        </div>

        {/* Save Button */}
        <Button onClick={handleSave} disabled={isSaving} className="w-full">
          {isSaving ? 'Saving...' : 'Save Profile'}
        </Button>
      </div>
    </div>
  )
}
