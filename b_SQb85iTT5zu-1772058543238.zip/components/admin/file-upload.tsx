'use client'

import { useState, useRef } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'

interface FileUploadProps {
  userId: string
  folder: string
  onUpload: (url: string) => void
  accept?: string
}

export default function FileUpload({
  userId,
  folder,
  onUpload,
  accept = '*',
}: FileUploadProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()
      // Generate unique filename
      const timestamp = Date.now()
      const ext = file.name.split('.').pop()
      const fileName = `${timestamp}.${ext}`
      const filePath = `${folder}/${userId}/${fileName}`

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('portfolio')
        .upload(filePath, file, { upsert: false })

      if (uploadError) throw uploadError

      // Get public URL
      const {
        data: { publicUrl },
      } = supabase.storage.from('portfolio').getPublicUrl(filePath)

      onUpload(publicUrl)

      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = ''
      }
    } catch (err) {
      console.error('Upload error:', err)
      setError('Failed to upload file. Check storage RLS policies.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-2">
      <input
        ref={fileInputRef}
        type="file"
        accept={accept}
        onChange={handleFileSelect}
        disabled={isLoading}
        className="hidden"
        aria-label="Upload file"
      />

      <Button
        type="button"
        variant="outline"
        disabled={isLoading}
        onClick={() => fileInputRef.current?.click()}
        className="w-full"
      >
        {isLoading ? 'Uploading...' : 'Choose File'}
      </Button>

      {error && <p className="text-sm text-red-600">{error}</p>}
    </div>
  )
}
