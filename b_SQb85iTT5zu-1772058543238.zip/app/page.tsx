'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import ProfileSection from '@/components/portfolio/profile-section'
import WorksGallery from '@/components/portfolio/works-gallery'

export const dynamic = 'force-dynamic'

export default function PortfolioPage() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = async () => {
      try {
        const supabase = createClient()
        const {
          data: { session },
        } = await supabase.auth.getSession()
      } catch (error) {
        console.error('Error initializing Supabase:', error)
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-pulse text-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <main className="flex w-full h-screen bg-background">
      {/* Desktop: Split layout - 1/3 profile, 2/3 works */}
      <div className="hidden md:flex w-full h-screen">
        {/* Left side - Profile Section (1/3) */}
        <div className="w-1/3 border-r border-border overflow-y-auto">
          <ProfileSection />
        </div>

        {/* Right side - Works Gallery (2/3) */}
        <div className="w-2/3 overflow-y-auto">
          <WorksGallery />
        </div>
      </div>

      {/* Mobile: Stack vertically */}
      <div className="md:hidden flex flex-col w-full h-screen overflow-y-auto">
        <ProfileSection />
        <div className="border-t border-border">
          <WorksGallery />
        </div>
      </div>
    </main>
  )
}
