import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: Request) {
  try {
    const cookieStore = await cookies()
    const isAuthenticated = cookieStore.get('admin_authenticated')?.value === 'true'

    if (isAuthenticated) {
      // Use a fixed UUID for the portfolio owner
      const fixedUserId = '550e8400-e29b-41d4-a716-446655440000'
      
      // Ensure profile exists
      try {
        const supabase = await createClient()
        const { data: existingProfile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', fixedUserId)
          .single()

        // If profile doesn't exist, create it
        if (!existingProfile) {
          await supabase
            .from('profiles')
            .insert([{ id: fixedUserId, username: 'admin' }])
        }
      } catch (err) {
        console.error('[v0] Error ensuring profile exists:', err)
        // Continue anyway - the profile manager will handle creation
      }

      return NextResponse.json({ authenticated: true, userId: fixedUserId })
    } else {
      return NextResponse.json({ authenticated: false }, { status: 401 })
    }
  } catch (error) {
    console.error('[v0] Auth check error:', error)
    return NextResponse.json({ authenticated: false }, { status: 401 })
  }
}
